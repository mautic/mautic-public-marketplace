Sample Mautic package for local dev download testing.
